# LicensePLateRecognize
An system which can recognize the characters from a car license plate

### Class:PhotoPro
1. PhotoPro类是用来加载并处理图像的

2. predict.py是利用了支持向量机机器学习后的一个用于学习的类

3. Process类调用前两者来对车牌进行抠图和识别的处理

4. GUI是图形界面

